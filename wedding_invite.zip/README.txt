Convite de casamento interativo - Paulo Henrique & Ana Júlia
Arquivos incluídos:
- index.html
- style.css
- script.js
- photo1.jpeg, photo2.jpeg, photo3.jpeg (fotos enviadas pelo usuário)

Instruções rápidas:
1. Descompacte o arquivo em um diretório e abra index.html no navegador para testar localmente.
2. Para publicar online, faça deploy no GitHub Pages ou Netlify (arraste a pasta para Netlify e publique).
3. Teste os botões: 'Abrir no GPS' abre o Maps, 'Confirmar por WhatsApp' abre o WhatsApp com mensagem pronta, 'Lista de presentes' abre a Amazon.

Links usados no convite:
- Maps: https://maps.app.goo.gl/aofvP4UmLajZzYe17?g_st=ipc
- WhatsApp: https://wa.me/5514981689120?text=Ol%C3%A1%21%20Confirmo%20minha%20presen%C3%A7a%20no%20casamento%20de%20Paulo%20Henrique%20%26%20Ana%20J%C3%BAlia%20%E2%80%94%2011/09/2027.
- Lista de presentes: https://www.amazon.com.br/?&tag=hydrbrabk-20&ref=pd_sl_7rwd1q78df_e&adgrpid=155790195778&hvpone=&hvptwo=&hvadid=677606588104&hvpos=&hvnetw=g&hvrand=16419518054285946479&hvqmt=e&hvdev=m&hvdvcmdl=&hvlocint=&hvlocphy=9216125&hvtargid=kwd-10573980&hydadcr=26346_11691057&gad_source=1
